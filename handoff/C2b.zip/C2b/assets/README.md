# C2b assets

C2b: The Weight Came Off. Her Face Didn’t Get the Message. 7 Mistakes Women Over 50 Make When Their Body Stops Using Sugar Well (Ceylon Cinnamon + Berberine prelander).

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line → "What’s happening / What’s really going on" box → "What Resilia does for you" benefits section → 7 mistake cards → CTA after #3 and after #6 → what people notice → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline → number + "Mistake: …" heading → media → body with a large product photo floated right (about half the card on desktop, full width under the text on phones; some cards have none) → "What changes:" line.

Every media element in the HTML has data-asset="name". Library images are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| cg-cin-mirror.jpg | new image (ChatGPT or PDP capture): A 61-year-old woman at her bathroom mirror touching her face, tired and disappointed | upload to theme assets (also embedded in the HTML) |
| cg-cin-cell.jpg | new image (ChatGPT or PDP capture): Illustration: insulin knocking on closed cell doors while sugar waits outside | upload to theme assets (also embedded in the HTML) |
| cg-cin-palm.jpg | new image (ChatGPT or PDP capture): A woman holding two Resilia capsules next to her morning coffee, the pouch behind her | upload to theme assets (also embedded in the HTML) |
| cg-cin-walk.jpg | new image (ChatGPT or PDP capture): A woman in her 60s power-walking along a suburban sidewalk at dawn | upload to theme assets (also embedded in the HTML) |
| cg-cin-wine.jpg | new image (ChatGPT or PDP capture): A woman eating a small salad alone at the kitchen counter, pushing away a glass of wine and the bread basket | upload to theme assets (also embedded in the HTML) |
| pdp-cin-pour.jpg | new image (ChatGPT or PDP capture): Resilia Ceylon Cinnamon capsules poured from the pouch into a glass jar | upload to theme assets (also embedded in the HTML) |
| cg-cin-pharm.jpg | new image (ChatGPT or PDP capture): A pharmacy counter stacked with a metabolism booster, collagen powder, apple cider vinegar gummies and green tea capsules | upload to theme assets (also embedded in the HTML) |
| pdp-cin-facts.jpg | new image (ChatGPT or PDP capture): Supplement Facts: Ceylon cinnamon bark extract 1,000 mg, berberine HCl 500 mg | upload to theme assets (also embedded in the HTML) |
| cg-cin-slump.jpg | new image (ChatGPT or PDP capture): A woman slumped on the couch at 3 p.m., coffee going cold | upload to theme assets (also embedded in the HTML) |
| cg-cin-rolls.jpg | new image (ChatGPT or PDP capture): Cassia (one thick, hard roll) next to true Ceylon cinnamon (thin, papery layers) | upload to theme assets (also embedded in the HTML) |
| cg-cin-tub.jpg | new image (ChatGPT or PDP capture): A woman in a white robe sitting on the edge of the bathtub, defeated, supplement bottles on the counter | upload to theme assets (also embedded in the HTML) |
| cg-cin-cafe.jpg | new image (ChatGPT or PDP capture): A friend showing the Resilia Ceylon Cinnamon pouch across a café table | upload to theme assets (also embedded in the HTML) |
| cg-cin-dress.jpg | new image (ChatGPT or PDP capture): A woman trying on a red dress in front of the bedroom mirror, a small hopeful smile | upload to theme assets (also embedded in the HTML) |
| pdp-cin-pouch.jpg | new image (ChatGPT or PDP capture): Resilia Ceylon Cinnamon with Berberine HCl pouch, 60 capsules | upload to theme assets (also embedded in the HTML) |

Fonts: Clash Grotesk (fallback Space Grotesk) for headlines and buttons, Figtree (UI), Source Serif 4 (body) via Google Fonts.
Colors (from the cinnamon PDP): ink #1F1A17, body #2E2622, accent #9B470D, soft box #F6EDE7 / border #E8D6C8, image background #F3E9E1, Trustpilot stars #00B67A.
CTA link (all buttons): https://resilia.shop/products/resilia-ceylon-cinnamon
Layout: single column, max width 660px, 16px side gutter.
Keep the ADVERTORIAL label, any ¹ study citation and every footer disclaimer exactly as written.
