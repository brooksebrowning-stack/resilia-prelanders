# G24 assets

G24: Puffy Ankles, Heavy Legs, Asleep by 7? 7 Mistakes Men Over 45 Make With Their Circulation (and What to Do Instead) Google prelander, Aged Odorless Garlic.

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line (Trustpilot 4.2 / 1,665 reviews, guarantee) → "What's happening / What's really going on" box → 7 mistake cards → CTA after #3 and after #6 → "What men notice" timeline + verified review quote → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline (uppercase, accent) → number + "Mistake: …" heading → media (some show two 1:1 images side by side) → body with a small product photo floated right → "Instead:" line.

Every media element in the HTML has data-asset="name". Library images and clips are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. Clips play as muted autoplay loops. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| lib-sock-marks-man | image: A man on the edge of his bed rubbing his feet, with deep sock marks around his swollen ankles | already hosted: https://resilia.shop/cdn/shop/files/rp-3da28a73-7a17-4750-b85e-b23c34227382.webp |
| lib-artery-flex-vs-stiff | image: A flexible artery next to a stiffer, narrower artery | already hosted: https://resilia.shop/cdn/shop/files/adv-05-mechanism.webp?v=1791228588&width=1200 |
| lib-ankles-sock-lines | image: Swollen ankles with deep sock lines | already hosted: https://resilia.shop/cdn/shop/files/adv32-f-socks.webp |
| g-legs-circulation.jpg | new image (ChatGPT): 3D render of the arteries running down the legs, bright near the top and fainter toward the feet | upload to theme assets (also embedded in the HTML) |
| g-pill-bedside-man.jpg | new image (ChatGPT): A man on the edge of his bed in grey socks holding two Resilia softgels, the pouch on his nightstand | upload to theme assets (also embedded in the HTML) |
| lib-stairs-stop | image: An older man stopped halfway up the stairs holding the rail, hand on his chest | already hosted: https://resilia.shop/cdn/shop/files/adv45-stairs.webp |
| g-artery-flex.jpg | new image (ChatGPT): 3D render of a flexible artery wall stretching with each heartbeat as blood cells flow through | upload to theme assets (also embedded in the HTML) |
| g-pill-palm-pour.jpg | new image (ChatGPT): A man tipping two Resilia softgels from the pouch into his palm in the kitchen | upload to theme assets (also embedded in the HTML) |
| lib-asleep-recliner | image: A man asleep in his recliner at 8 p.m. in the glow of the TV | already hosted: https://resilia.shop/cdn/shop/files/adv58-s_recliner.webp |
| lib-anim-heart | image: Looping render of a heart glowing warmer as its cells make energy | already hosted: https://resilia.shop/cdn/shop/files/adv58-anim_heart.webp |
| g-pill-nightstand.jpg | new image (ChatGPT): The Resilia pouch on a nightstand in the evening with two softgels in a dish | upload to theme assets (also embedded in the HTML) |
| lib-out-of-breath | image: A man bent over halfway up outdoor stairs, out of breath | already hosted: https://resilia.shop/cdn/shop/files/adv57-m_sweat.webp |
| g-k2-calcium-bone.jpg | new image (ChatGPT): 3D render of calcium particles travelling into a bone while the artery below stays clear | upload to theme assets (also embedded in the HTML) |
| g-pill-kitchen-coffee.jpg | new image (ChatGPT): The Resilia pouch on a kitchen counter next to morning coffee, a hand reaching for two softgels | upload to theme assets (also embedded in the HTML) |
| lib-garlic-jars-3 | image: Three jars of garlic cloves: fresh white, golden, and dark amber | already hosted: https://resilia.shop/cdn/shop/files/w4-adv25-jars.webp |
| g-pill-cutting-board.jpg | new image (ChatGPT): Fresh garlic bulbs on a cutting board with the Resilia pouch and two softgels behind | upload to theme assets (also embedded in the HTML) |
| lib-clip-softgel-pour | looping video clip: Amber softgels poured from the Resilia Aged Odorless Garlic pouch | already hosted: https://cdn.shopify.com/videos/c/o/v/001108ea9ee643528f8d4f5d8f3eeef4.mp4 |
| g-pill-bottles-aside.jpg | new image (ChatGPT): The Resilia pouch in front with three plain supplement bottles pushed to the side | upload to theme assets (also embedded in the HTML) |
| lib-clip-stairs-easy | looping video clip: The same man walking down the stairs easily, carrying his granddaughter | already hosted: https://cdn.shopify.com/videos/c/o/v/a1323f9498ed429085d6e8f66db83da8.mp4 |
| lib-pouch | image: Resilia Aged Odorless Garlic with CoQ10 Ubiquinol pouch | already hosted: https://resilia.shop/cdn/shop/files/adv-13-product-front.png?v=1791228633&width=640 |

Fonts: Figtree (UI/labels/subheadlines), Source Serif 4 (headlines/body) via Google Fonts.
Colors: ink #2A1E1A, body #3B2F2A, accent #8A2B1F, soft box #FAF5EF / border #EADFD3, image background #F4EEE6, Trustpilot stars #00B67A.
Layout: single column, max width 660px, 16px side gutter.
CTA link (all buttons): https://resilia.shop/products/resilia-aged-odorless-garlic
Keep the ADVERTORIAL label, the ¹ study citation and every footer disclaimer exactly as written.
