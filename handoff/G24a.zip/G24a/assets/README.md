# G24a assets

G24a: Asleep in the Chair by 7 and She’s Stopped Looking at You? 7 Mistakes Men Over 45 Make When They Start Losing Their Edge (Aged Odorless Garlic prelander).

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line → "What’s happening / What’s really going on" box → 7 mistake cards → CTA after #3 and after #6 → what people notice → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline → number + "Mistake: …" heading → media → body with a large product photo floated right (about half the card on desktop, full width under the text on phones; some cards have none) → "Instead:" line.

Every media element in the HTML has data-asset="name". Library images are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| lib-bedroom-distance | image: A man sitting on the edge of the bed, lost in thought, while his wife sleeps turned away | already hosted: https://resilia.shop/cdn/shop/files/Rectangle_161129_23e0293e-8586-414e-8587-54d4fe912ffe.png?v=1790278308&width=960 |
| lib-artery-flex-vs-stiff | image: A flexible artery next to a stiffer, narrower artery | already hosted: https://resilia.shop/cdn/shop/files/adv-05-mechanism.webp?v=1791228588&width=1200 |
| lib-asleep-recliner | image: A man asleep in his recliner at 8 p.m. in the glow of the TV | already hosted: https://resilia.shop/cdn/shop/files/adv58-s_recliner.webp |
| g-artery-flex.jpg | new image (ChatGPT or PDP capture): 3D render of a flexible artery wall stretching with each heartbeat as blood cells flow through | upload to theme assets (also embedded in the HTML) |
| g-pill-nightstand.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a nightstand in the evening with two softgels in a dish | upload to theme assets (also embedded in the HTML) |
| lib-belly-kitchen | image: A man in his kitchen pulling up his shirt and looking down at his belly | already hosted: https://resilia.shop/cdn/shop/files/Rectangle_161129_ff667c37-4aa8-4ef7-bf34-5046c2ef23a2.png?v=1790278282&width=960 |
| g-pill-kitchen-coffee.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a kitchen counter next to morning coffee, a hand reaching for two softgels | upload to theme assets (also embedded in the HTML) |
| lib-stairs-stop | image: An older man stopped halfway up the stairs holding the rail, hand on his chest | already hosted: https://resilia.shop/cdn/shop/files/adv45-stairs.webp |
| lib-garlic-jars | image: Three jars of garlic aging on a dark shelf, darker from left to right | already hosted: https://resilia.shop/cdn/shop/files/adv45-jars.webp |
| g-pill-palm-pour.jpg | new image (ChatGPT or PDP capture): A man tipping two Resilia softgels from the pouch into his palm in the kitchen | upload to theme assets (also embedded in the HTML) |
| lib-desk-tired | image: A man at his office desk rubbing his eyes, worn out | already hosted: https://resilia.shop/cdn/shop/files/Rectangle_161129_1_fab5a56a-c4aa-4dfc-a378-03928d5d6907.png?v=1788299634&width=960 |
| lib-anim-heart | image: Looping render of a heart glowing warmer as its cells make energy | already hosted: https://resilia.shop/cdn/shop/files/adv58-anim_heart.webp |
| g-pill-bedside-man.jpg | new image (ChatGPT or PDP capture): A man on the edge of his bed in grey socks holding two Resilia softgels, the pouch on his nightstand | upload to theme assets (also embedded in the HTML) |
| lib-out-of-breath | image: A man bent over halfway up outdoor stairs, out of breath | already hosted: https://resilia.shop/cdn/shop/files/adv57-m_sweat.webp |
| g-k2-calcium-bone.jpg | new image (ChatGPT or PDP capture): 3D render of calcium particles travelling into a bone while the artery below stays clear | upload to theme assets (also embedded in the HTML) |
| g-pill-cutting-board.jpg | new image (ChatGPT or PDP capture): Fresh garlic bulbs on a cutting board with the Resilia pouch and two softgels behind | upload to theme assets (also embedded in the HTML) |
| lib-couple-dinner | image: An older couple smiling at the dinner table while the man shows two amber softgels in his palm | already hosted: https://resilia.shop/cdn/shop/files/adv45-s_dinner.webp |
| g-pill-bottles-aside.jpg | new image (ChatGPT or PDP capture): The Resilia pouch in front with three plain supplement bottles pushed to the side | upload to theme assets (also embedded in the HTML) |
| lib-garlic-jars-3 | image: Three jars of garlic cloves: fresh white, golden, and dark amber | already hosted: https://resilia.shop/cdn/shop/files/w4-adv25-jars.webp |
| lib-pouch | image: Resilia Aged Odorless Garlic with CoQ10 Ubiquinol pouch | already hosted: https://resilia.shop/cdn/shop/files/adv-13-product-front.png?v=1791228633&width=640 |

Fonts: Figtree (UI/labels/subheadlines), Source Serif 4 (headlines/body) via Google Fonts.
Colors: ink #2A1E1A, body #3B2F2A, accent #8A2B1F, soft box #FAF5EF / border #EADFD3, image background #F4EEE6, Trustpilot stars #00B67A.
CTA link (all buttons): https://resilia.shop/products/resilia-aged-odorless-garlic
Layout: single column, max width 660px, 16px side gutter.
Keep the ADVERTORIAL label, any ¹ study citation and every footer disclaimer exactly as written.
