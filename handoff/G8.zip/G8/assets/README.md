# G8 assets

G8: His Wife Came Home After 6 Weeks and Called 911 on Him. The 7 Mistakes Mike Made Before His Trainer Told Him the Truth (Aged Odorless Garlic prelander).

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line → "What’s happening / What’s really going on" box → 7 mistake cards → CTA after #3 and after #6 → what people notice → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline → number + "Mistake: …" heading → media → body with a large product photo floated right (about half the card on desktop, full width under the text on phones; some cards have none) → "Instead:" line.

Every media element in the HTML has data-asset="name". Library images are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| cg-g8-door.jpg | new image (ChatGPT or PDP capture): Mike’s wife frozen in the doorway after six weeks away, staring at the man in her hallway | upload to theme assets (also embedded in the HTML) |
| ad-g8-rafael.jpg | new image (ChatGPT or PDP capture): Rafael, 54, the trainer, looking straight at Mike | upload to theme assets (also embedded in the HTML) |
| cg-g8-salad.jpg | new image (ChatGPT or PDP capture): Mike eating a bowl of salad standing at the kitchen counter | upload to theme assets (also embedded in the HTML) |
| g-pill-kitchen-coffee.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a kitchen counter next to morning coffee, a hand reaching for two softgels | upload to theme assets (also embedded in the HTML) |
| ad-g8-stairs.jpg | new image (ChatGPT or PDP capture): Mike stopped on the stairs, gripping the rail | upload to theme assets (also embedded in the HTML) |
| g-pill-palm-pour.jpg | new image (ChatGPT or PDP capture): A man tipping two Resilia softgels from the pouch into his palm in the kitchen | upload to theme assets (also embedded in the HTML) |
| ad-g8-face.jpg | new image (ChatGPT or PDP capture): Close-up of Mike looking tired and puffy | upload to theme assets (also embedded in the HTML) |
| g-pill-nightstand.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a nightstand in the evening with two softgels in a dish | upload to theme assets (also embedded in the HTML) |
| ad-g8-gym.jpg | new image (ChatGPT or PDP capture): Mike in a red tracksuit walking into the gym | upload to theme assets (also embedded in the HTML) |
| g-pill-bedside-man.jpg | new image (ChatGPT or PDP capture): A man on the edge of his bed in grey socks holding two Resilia softgels, the pouch on his nightstand | upload to theme assets (also embedded in the HTML) |
| ad-g8-rafael2.jpg | new image (ChatGPT or PDP capture): Rafael explaining at the gym | upload to theme assets (also embedded in the HTML) |
| g-pill-bottles-aside.jpg | new image (ChatGPT or PDP capture): The Resilia pouch in front with three plain supplement bottles pushed to the side | upload to theme assets (also embedded in the HTML) |
| ad-g8-pouch.jpg | new image (ChatGPT or PDP capture): Mike holding the Resilia Aged Odorless Garlic pouch | upload to theme assets (also embedded in the HTML) |
| g-pill-cutting-board.jpg | new image (ChatGPT or PDP capture): Fresh garlic bulbs on a cutting board with the Resilia pouch and two softgels behind | upload to theme assets (also embedded in the HTML) |
| ad-g8-day30.jpg | new image (ChatGPT or PDP capture): Mike back at the gym on day 30, lifting | upload to theme assets (also embedded in the HTML) |
| lib-pouch | image: Resilia Aged Odorless Garlic with CoQ10 Ubiquinol pouch | already hosted: https://resilia.shop/cdn/shop/files/adv-13-product-front.png?v=1791228633&width=640 |

Fonts: Figtree (UI/labels/subheadlines), Source Serif 4 (headlines/body) via Google Fonts.
Colors: ink #2A1E1A, body #3B2F2A, accent #8A2B1F, soft box #FAF5EF / border #EADFD3, image background #F4EEE6, Trustpilot stars #00B67A.
CTA link (all buttons): https://resilia.shop/products/resilia-aged-odorless-garlic
Layout: single column, max width 660px, 16px side gutter.
Keep the ADVERTORIAL label, any ¹ study citation and every footer disclaimer exactly as written.
