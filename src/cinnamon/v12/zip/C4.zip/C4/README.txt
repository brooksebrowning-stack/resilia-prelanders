C4 - Resilia Ceylon Cinnamon prelander (written to Compliance Guide v1.2, Nov 25 2026)

- C4.html is a single self-contained file (images embedded as data URIs) and is the source of truth for copy.
- assets/ holds the same images as separate JPGs. Every <img> in the HTML has data-asset="<slot>.jpg"; the slot -> file map is in assets/MAP.txt so you can swap in hosted URLs.
- Layout, fonts and colors match C2b (same CSS).
- All CTAs go to https://resilia.shop/products/resilia-ceylon-cinnamon
- Keep the advertorial label, the dramatization line (C7 only), and every disclaimer, guarantee and advisory line exactly as written.
- REVIEWS: the two review cards are real customer reviews quoted word for word. Before launch, replace "[date from review platform]" with each review's date from Resilia's review platform. Compliance (Waqas) must approve the reviews.
- Images are stand-ins from the existing cinnamon set; replacement ChatGPT images may follow.
- Needs Waqas's sign-off before launch.
