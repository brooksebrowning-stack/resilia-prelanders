# C3a assets

C3a: Scared to Eat Because Every Meal Sends Your Number Up? 7 Mistakes People Make With Their Blood Sugar (and What Actually Helps) (Ceylon Cinnamon + Berberine prelander).

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line → "What’s happening / What’s really going on" box → "What Resilia does for you" benefits section → 7 mistake cards → CTA after #3 and after #6 → what people notice → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline → number + "Mistake: …" heading → media → body with a large product photo floated right (about half the card on desktop, full width under the text on phones; some cards have none) → "What changes:" line.

Every media element in the HTML has data-asset="name". Library images are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| cg-cin-salad.jpg | new image (ChatGPT or PDP capture): A man in his 60s with a small salad and a glucose meter while his family eats pasta | upload to theme assets (also embedded in the HTML) |
| cg-cin-cell.jpg | new image (ChatGPT or PDP capture): Illustration: insulin knocking on closed cell doors while sugar waits outside | upload to theme assets (also embedded in the HTML) |
| cg-cin-palm.jpg | new image (ChatGPT or PDP capture): A woman holding two Resilia capsules next to her morning coffee, the pouch behind her | upload to theme assets (also embedded in the HTML) |
| cg-cin-wine.jpg | new image (ChatGPT or PDP capture): A woman eating a small salad alone at the kitchen counter, pushing away a glass of wine and the bread basket | upload to theme assets (also embedded in the HTML) |
| pdp-cin-pour.jpg | new image (ChatGPT or PDP capture): Resilia Ceylon Cinnamon capsules poured from the pouch into a glass jar | upload to theme assets (also embedded in the HTML) |
| cg-cin-couch.jpg | new image (ChatGPT or PDP capture): A man exhausted on the couch an hour after dinner | upload to theme assets (also embedded in the HTML) |
| pdp-cin-facts.jpg | new image (ChatGPT or PDP capture): Supplement Facts: Ceylon cinnamon bark extract 1,000 mg, berberine HCl 500 mg | upload to theme assets (also embedded in the HTML) |
| cg-cin-cake.jpg | new image (ChatGPT or PDP capture): A man declining a slice of birthday cake while his wife watches his plate | upload to theme assets (also embedded in the HTML) |
| cg-cin-papers.jpg | new image (ChatGPT or PDP capture): A stack of research papers with charts, reading glasses on top | upload to theme assets (also embedded in the HTML) |
| cg-cin-rolls.jpg | new image (ChatGPT or PDP capture): Cassia (one thick, hard roll) next to true Ceylon cinnamon (thin, papery layers) | upload to theme assets (also embedded in the HTML) |
| cg-cin-pills.jpg | new image (ChatGPT or PDP capture): A man overwhelmed at the kitchen table with a pill organizer, bottles, a glucose meter and a notebook of numbers | upload to theme assets (also embedded in the HTML) |
| cg-cin-breakfast.jpg | new image (ChatGPT or PDP capture): A man laughing at a family breakfast with his wife and grandkids | upload to theme assets (also embedded in the HTML) |
| pdp-cin-pouch.jpg | new image (ChatGPT or PDP capture): Resilia Ceylon Cinnamon with Berberine HCl pouch, 60 capsules | upload to theme assets (also embedded in the HTML) |

Fonts: Clash Grotesk (fallback Space Grotesk) for headlines and buttons, Figtree (UI), Source Serif 4 (body) via Google Fonts.
Colors (from the cinnamon PDP): ink #1F1A17, body #2E2622, accent #9B470D, soft box #F6EDE7 / border #E8D6C8, image background #F3E9E1, Trustpilot stars #00B67A.
CTA link (all buttons): https://resilia.shop/products/resilia-ceylon-cinnamon
Layout: single column, max width 660px, 16px side gutter.
Keep the ADVERTORIAL label, any ¹ study citation and every footer disclaimer exactly as written.
