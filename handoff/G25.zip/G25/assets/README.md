# G25 assets

G25: Your Blood Pressure Number Is Only the Warning Light. 7 Mistakes Men Make About What’s Behind It (and What Japanese Men Do Instead) Google prelander, Aged Odorless Garlic.

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line (Trustpilot 4.2 / 1,665 reviews, guarantee) → "What's happening / What's really going on" box → 7 mistake cards → CTA after #3 and after #6 → "What men notice" timeline + verified review quote → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline (uppercase, accent) → number + "Mistake: …" heading → media (some show two 1:1 images side by side) → body with a small product photo floated right → "Instead:" line.

Every media element in the HTML has data-asset="name". Library images and clips are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. Clips play as muted autoplay loops. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| lib-bp-cuff | image: A man at his kitchen table with a blood pressure cuff on his arm | already hosted: https://resilia.shop/cdn/shop/files/rp-bec47cfb-8b8d-4b15-89c0-4e08bfcb5796.webp |
| lib-artery-stiff | image: Illustration of a stiff artery narrowed by deposits | already hosted: https://resilia.shop/cdn/shop/files/rp-9f83ab60-ea0d-4ff5-afb8-aae52a79f24f.webp |
| g-bp-monitor-japan.jpg | new image (ChatGPT): A Japanese man calmly reading his home blood pressure monitor and logging the number in a notebook | upload to theme assets (also embedded in the HTML) |
| g-bp-monitor.jpg | new image (ChatGPT): A home blood pressure monitor showing a high reading, a man with the cuff on his arm behind it | upload to theme assets (also embedded in the HTML) |
| g-pill-palm-pour.jpg | new image (ChatGPT): A man tipping two Resilia softgels from the pouch into his palm in the kitchen | upload to theme assets (also embedded in the HTML) |
| lib-okada-jars | image: An older Japanese man showing a cupboard of glass jars of aging garlic | already hosted: https://resilia.shop/cdn/shop/files/adv32-s-jars.webp |
| g-pill-tea-japan.jpg | new image (ChatGPT): A Japanese man taking a Resilia softgel with his morning green tea | upload to theme assets (also embedded in the HTML) |
| lib-porch-chest | image: A man stopped on the porch steps with one hand on his chest | already hosted: https://resilia.shop/cdn/shop/files/w5-adv27-hero.webp |
| g-artery-flex.jpg | new image (ChatGPT): 3D render of a flexible artery wall stretching with each heartbeat as blood cells flow through | upload to theme assets (also embedded in the HTML) |
| g-pill-cutting-board.jpg | new image (ChatGPT): Fresh garlic bulbs on a cutting board with the Resilia pouch and two softgels behind | upload to theme assets (also embedded in the HTML) |
| lib-afternoon-nap | image: A man asleep in a recliner in the afternoon | already hosted: https://resilia.shop/cdn/shop/files/adv32-f-nap.webp |
| lib-anim-heart | image: Looping render of a heart glowing warmer as its cells make energy | already hosted: https://resilia.shop/cdn/shop/files/adv58-anim_heart.webp |
| g-pill-walk-japan.jpg | new image (ChatGPT): A Japanese man in a light jacket taking his Resilia softgels before a morning walk | upload to theme assets (also embedded in the HTML) |
| g-k2-calcium-bone.jpg | new image (ChatGPT): 3D render of calcium particles travelling into a bone while the artery below stays clear | upload to theme assets (also embedded in the HTML) |
| g-pill-nightstand.jpg | new image (ChatGPT): The Resilia pouch on a nightstand in the evening with two softgels in a dish | upload to theme assets (also embedded in the HTML) |
| g-lab-report-japan.jpg | new image (ChatGPT): A Japanese man reading his blood test results at home, the Resilia pouch and green tea on the table | upload to theme assets (also embedded in the HTML) |
| g-pill-kitchen-coffee.jpg | new image (ChatGPT): The Resilia pouch on a kitchen counter next to morning coffee, a hand reaching for two softgels | upload to theme assets (also embedded in the HTML) |
| lib-garlic-jars | image: Three jars of garlic aging on a dark shelf, darker from left to right | already hosted: https://resilia.shop/cdn/shop/files/adv45-jars.webp |
| g-pill-bottles-aside.jpg | new image (ChatGPT): The Resilia pouch in front with three plain supplement bottles pushed to the side | upload to theme assets (also embedded in the HTML) |
| lib-pouch | image: Resilia Aged Odorless Garlic with CoQ10 Ubiquinol pouch | already hosted: https://resilia.shop/cdn/shop/files/adv-13-product-front.png?v=1791228633&width=640 |

Fonts: Figtree (UI/labels/subheadlines), Source Serif 4 (headlines/body) via Google Fonts.
Colors: ink #2A1E1A, body #3B2F2A, accent #8A2B1F, soft box #FAF5EF / border #EADFD3, image background #F4EEE6, Trustpilot stars #00B67A.
Layout: single column, max width 660px, 16px side gutter.
CTA link (all buttons): https://resilia.shop/products/resilia-aged-odorless-garlic
Keep the ADVERTORIAL label, the ¹ study citation and every footer disclaimer exactly as written.
