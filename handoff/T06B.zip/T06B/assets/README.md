# T06B assets

T06b: 7 signs your body is clearing out (lymph version). Google prelander, Oil of Oregano.

Images in page order (first appearance). Each <img> in the HTML has data-asset="filename" so you can swap in hosted URLs.

| File | Size (px) | Note |
|---|---|---|
| t06b-hero.jpg | 1400x1050 | upload to theme assets |
| lymphatic-system.jpg | 524x703 | already hosted: https://resilia.shop/cdn/shop/files/hf_20260803_191106_e4857c9a-536a-44b7-a4f9-d39a8ad4175a.png?v=1785785207&width=700 |
| oregano-oil.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/oregano-oil.png?v=1784834824&width=900 |
| black-seed-oil.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/black-seed-oil.png?v=1784834838&width=900 |
| softgels-pouch-pour.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/oregano-updated-7.webp?v=1788792410&width=900 |
| t06-pouch.webp | 900x900 | upload to theme assets |

Fonts: Figtree (400-900) for UI/labels, Source Serif 4 (400-800) for headlines and body (Google Fonts).
Colors: ink #1F2419, body #2F3429, green #3F5A1E (buttons, numbers, highlight), brown #7A4A12 (eyebrows), soft box #F3F6EE / border #DCE5CF, divider #E1E6D8.
Layout: single column, max width 660px, 16px side gutter.
CTA link: https://resilia.shop/products/resilia-oil-of-oregano-softgels
Keep the ADVERTORIAL label and every footer disclaimer exactly as written.
