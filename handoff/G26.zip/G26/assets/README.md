# G26 assets

G26: Training Hard and the Gut Won’t Budge? 7 Mistakes Men Over 45 Make With Their Blood Flow (and What to Do Instead) (Aged Odorless Garlic prelander).

Structure (top to bottom): eyebrow → headline → subheadline → byline → hero → intro → CTA + trust line → 7 mistake cards → CTA after #3 and after #6 → what people notice → 30-day guarantee box → "Is Resilia for someone like me?" + what's in every serving → product box → FAQ → disclaimers.

Each mistake card: symptom subheadline → number + "Mistake: …" heading → media → body with a large product photo floated right (about half the card on desktop, full width under the text on phones; some cards have none) → "Instead:" line.

Every media element in the HTML has data-asset="name". Library images are already hosted on resilia.shop / Shopify CDN: use those URLs as-is. New images are in this folder.

| File | What it is | Source |
|---|---|---|
| lib-gym-man | image: A man in his 50s sitting in the gym, tired and frustrated | already hosted: https://resilia.shop/cdn/shop/files/Rectangle_161129_2_454b633f-64d1-4155-a9ff-bd71bbef7150.png?v=1788298857&width=960 |
| lib-anim-belt | image: Looping render: a man’s belly pushing out against his belt | already hosted: https://resilia.shop/cdn/shop/files/adv57-anim_belt.webp |
| g-legs-circulation.jpg | new image (ChatGPT or PDP capture): 3D render of the arteries running down the legs, bright near the top and fainter toward the feet | upload to theme assets (also embedded in the HTML) |
| g-pill-palm-pour.jpg | new image (ChatGPT or PDP capture): A man tipping two Resilia softgels from the pouch into his palm in the kitchen | upload to theme assets (also embedded in the HTML) |
| lib-desk-tired | image: A man at his office desk rubbing his eyes, worn out | already hosted: https://resilia.shop/cdn/shop/files/Rectangle_161129_1_fab5a56a-c4aa-4dfc-a378-03928d5d6907.png?v=1788299634&width=960 |
| lib-anim-heart | image: Looping render of a heart glowing warmer as its cells make energy | already hosted: https://resilia.shop/cdn/shop/files/adv58-anim_heart.webp |
| g-pill-nightstand.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a nightstand in the evening with two softgels in a dish | upload to theme assets (also embedded in the HTML) |
| lib-treadmill-laundry | image: A basement treadmill covered in folded laundry | already hosted: https://resilia.shop/cdn/shop/files/adv58-f_tread.webp |
| g-artery-flex.jpg | new image (ChatGPT or PDP capture): 3D render of a flexible artery wall stretching with each heartbeat as blood cells flow through | upload to theme assets (also embedded in the HTML) |
| g-pill-kitchen-coffee.jpg | new image (ChatGPT or PDP capture): The Resilia pouch on a kitchen counter next to morning coffee, a hand reaching for two softgels | upload to theme assets (also embedded in the HTML) |
| lib-diet-salad | image: A man at his kitchen table staring at a small dry salad and a black coffee, tired and unconvinced | already hosted: https://resilia.shop/cdn/shop/files/adv57-m_starve.webp |
| g-pill-bedside-man.jpg | new image (ChatGPT or PDP capture): A man on the edge of his bed in grey socks holding two Resilia softgels, the pouch on his nightstand | upload to theme assets (also embedded in the HTML) |
| lib-out-of-breath | image: A man bent over halfway up outdoor stairs, out of breath | already hosted: https://resilia.shop/cdn/shop/files/adv57-m_sweat.webp |
| g-k2-calcium-bone.jpg | new image (ChatGPT or PDP capture): 3D render of calcium particles travelling into a bone while the artery below stays clear | upload to theme assets (also embedded in the HTML) |
| g-pill-cutting-board.jpg | new image (ChatGPT or PDP capture): Fresh garlic bulbs on a cutting board with the Resilia pouch and two softgels behind | upload to theme assets (also embedded in the HTML) |
| lib-garlic-jars-3 | image: Three jars of garlic cloves: fresh white, golden, and dark amber | already hosted: https://resilia.shop/cdn/shop/files/w4-adv25-jars.webp |
| g-pill-bottles-aside.jpg | new image (ChatGPT or PDP capture): The Resilia pouch in front with three plain supplement bottles pushed to the side | upload to theme assets (also embedded in the HTML) |
| lib-clip-stairs-easy.mp4 | looping video clip: The same man walking down the stairs easily, carrying his granddaughter | already hosted: https://cdn.shopify.com/videos/c/o/v/a1323f9498ed429085d6e8f66db83da8.mp4 |
| lib-pouch | image: Resilia Aged Odorless Garlic with CoQ10 Ubiquinol pouch | already hosted: https://resilia.shop/cdn/shop/files/adv-13-product-front.png?v=1791228633&width=640 |

Fonts: Figtree (UI/labels/subheadlines), Source Serif 4 (headlines/body) via Google Fonts.
Colors: ink #2A1E1A, body #3B2F2A, accent #8A2B1F, soft box #FAF5EF / border #EADFD3, image background #F4EEE6, Trustpilot stars #00B67A.
CTA link (all buttons): https://resilia.shop/products/resilia-aged-odorless-garlic
Layout: single column, max width 660px, 16px side gutter.
Keep the ADVERTORIAL label, any ¹ study citation and every footer disclaimer exactly as written.
