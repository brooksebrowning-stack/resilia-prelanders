# T06A assets

T06a: 7 signs your body is holding on to stress (cortisol version). Google prelander, Oil of Oregano.

Images in page order (first appearance). Each <img> in the HTML has data-asset="filename" so you can swap in hosted URLs.

| File | Size (px) | Note |
|---|---|---|
| t06a-hero.jpg | 1400x1050 | upload to theme assets |
| t06a-sign-1.jpg | 240x240 | upload to theme assets |
| t06a-sign-2.jpg | 240x240 | upload to theme assets |
| t06a-sign-3.jpg | 240x240 | upload to theme assets |
| t06a-sign-4.jpg | 240x240 | upload to theme assets |
| t06a-sign-5.jpg | 240x240 | upload to theme assets |
| t06a-sign-6.jpg | 240x240 | upload to theme assets |
| t06a-sign-7.jpg | 240x240 | upload to theme assets |
| black-seed-oil.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/black-seed-oil.png?v=1784834838&width=900 |
| oregano-oil.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/oregano-oil.png?v=1784834824&width=900 |
| softgels-pouch-pour.jpg | 640x640 | already hosted: https://resilia.shop/cdn/shop/files/oregano-updated-7.webp?v=1788792410&width=900 |
| t06-pouch.webp | 900x900 | upload to theme assets |

Fonts: Figtree (400-900) for UI/labels, Source Serif 4 (400-800) for headlines and body (Google Fonts).
Colors: ink #1F2419, body #2F3429, green #3F5A1E (buttons, numbers, highlight), brown #7A4A12 (eyebrows), soft box #F3F6EE / border #DCE5CF, divider #E1E6D8.
Layout: single column, max width 660px, 16px side gutter. Sign thumbnails 84x84, 12px radius, number badge on the top-left corner.
CTA link: https://resilia.shop/products/resilia-oil-of-oregano-softgels
Keep the ADVERTORIAL label and every footer disclaimer exactly as written.
